package com.itechnotion.wpnews;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.MobileAds;
import com.itechnotion.wpnews.Evenements.AdapterEventment;
import com.itechnotion.wpnews.Evenements.EvenmentDataBean;
import com.itechnotion.wpnews.Home.CategoriesBean;
import com.itechnotion.wpnews.Home.MyAdapter;

import com.itechnotion.wpnews.retrofit.RestClient;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.gson.JsonElement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class AlldataFragment extends Fragment implements MyAdapter.OnCategorySelectedListner, AdapterEventment.OnNewsidSelectedListner/*, AdapterEventment.OnLoadMoreListener*/ {

    TextView selectedText;
    RecyclerView rvcate, rvalldata;
    private MyAdapter myAdapter;
    private ArrayList<CategoriesBean> categorylist = new ArrayList<>();
    private AdapterEventment adapterEventment;
    private ArrayList<EvenmentDataBean> eventmentlist = new ArrayList<>();
    ProgressDialog progressDialog;
    String catid;
    String catidfromdrawer="";
    int positionFromDrawer=0;
    int pager;
    String newsId;
    String selectedId;
    private AdView mAdView;
    private int per_page = 1;
    LinearLayout llNoDataFound;
    public AlldataFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_alldata, container, false);
        Initialization(v);
        return v;
    }
    private void Initialization(View v){
        ProgressDialogSetup();
        Bundle bundle=getArguments();
        selectedId=bundle.getString("cId");
        selectedText = v.findViewById(R.id.settextitemall);
        rvalldata = (RecyclerView) v.findViewById(R.id.rvalldata);
        rvcate = (RecyclerView) v.findViewById(R.id.rvalcat);
        myAdapter = new MyAdapter(getActivity(), categorylist);
        rvcate.setAdapter(myAdapter);
        myAdapter.setOnCategorySelectedListner(this);
        mAdView = v.findViewById(R.id.adView1);
        llNoDataFound = v.findViewById(R.id.llNoDataFound);
        if (Build.VERSION.SDK_INT < 16){
            Banner();
        }
        Banner();
        Category();
    }
    public  void Banner(){

        AdView adView = new AdView(getActivity());
        adView.setAdUnitId("ca-app-pub-1033682613036596/2383721070");
        MobileAds.initialize(getActivity(), "ca-app-pub-1033682613036596~8350363625");
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }
            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }
            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }
            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }
            @Override
            public void onAdClosed() {
                // Code to be executed when when the user is about to return
                // to the app after tapping on an ad.
            }
        });

    }
    private void ProgressDialogSetup() {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage(getResources().getString(R.string.please_wait));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            catidfromdrawer = bundle.getString("id");
            positionFromDrawer = bundle.getInt("position");
        }
    }


    private void Category() {
        progressDialog.show();
        Call<JsonElement> call1 = RestClient.post().category();
        call1.enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                progressDialog.dismiss();
                Log.e("Cat", response.body().toString());
                try {
                    if (response.isSuccessful()) {
                        JSONArray jsonArr = new JSONArray(response.body().toString());
                        if (jsonArr.length() > 0) {
                            categorylist.clear();
                            for (int i = 0; i < jsonArr.length(); i++) {

                                    JSONObject json2 = jsonArr.getJSONObject(i);
                                if (json2.getString("parent").equals("0")) {
                                    String name = String.valueOf(Html.fromHtml(json2.getString("name")));
                                    String id = json2.getString("id");
                                    String pid = json2.getString("parent");
                                    categorylist.add(new CategoriesBean(id, name, pid, false));
                                }
                            }
                        }
                        bindCategoryAdapter();
                        Log.e("Cat size : ", categorylist.size() + "");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void getNewsId(final int per_page) {
     /*   if (per_page == 1) {
        progressDialog.show();
         }
*/
        progressDialog.show();
        Call<JsonElement> call1 = RestClient.post().getNewsByCatID(catid);
        call1.enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                progressDialog.dismiss();
//                Log.e("News", response.body().toString());
                try {
                    if (response.isSuccessful()) {
                        JSONArray jsonArr = new JSONArray(response.body().toString());
                      /*  if (per_page == 1) {*/
                            if (jsonArr.length() > 0) {
                                eventmentlist.clear();
                                for (int i = 0; i < jsonArr.length(); i++) {
                                    JSONObject json2 = jsonArr.getJSONObject(i);
                                    String id = json2.getString("id");
                                    JSONObject objtitle = json2.getJSONObject("title");
                                    String title = objtitle.getString("rendered");
                                    String category = null;
                                    String date = json2.getString("date");
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                    DateFormat targetFormat = new SimpleDateFormat("MMMM dd yyyy");
                                    String formattedDate = null;
                                    Date convertedDate = new Date();
                                    try {
                                        convertedDate = dateFormat.parse(date);
                                        System.out.println(date);
                                        formattedDate = targetFormat.format(convertedDate);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }
                                    Log.e("date", formattedDate);
                                    String img = json2.getString("featured_image_link");
                                    JSONArray cattitle = json2.getJSONArray("category_arr");
                                    for (int j = 0; j <cattitle.length() ; j++) {
                                        JSONObject cat = cattitle.getJSONObject(j);
                                        category = String.valueOf(Html.fromHtml(cat.getString("name")));
                                    }
                                   
                                    eventmentlist.add(new EvenmentDataBean(id, title, formattedDate,/*unlike,*/ img, category));
                                    bindCategoryAdapternews();
                                }

                            }else {
                                Toast.makeText(getActivity(), "No recored available", Toast.LENGTH_SHORT).show();
                            }/*else {
                                eventmentlist.remove(eventmentlist.size() - 1);
                                adapterEventment.notifyItemRemoved(eventmentlist.size());
                                if (jsonArr.length() > 0) {
                                    eventmentlist.clear();
                                    for (int i = 0; i < jsonArr.length(); i++) {
                                        JSONObject json2 = jsonArr.getJSONObject(i);
                                        String id = json2.getString("id");
                                        JSONObject objtitle = json2.getJSONObject("title");
                                        String title = objtitle.getString("rendered");
                                        //  json2.getJSONObject(json2.getString("title"));
                              *//*  String like = json2.getString("like_count");
                                 String unlike = json2.getString("unlike_count");*//*
                                        String date = json2.getString("date");
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                        DateFormat targetFormat = new SimpleDateFormat("MMMM dd yyyy");
                                        String formattedDate = null;
                                        Date convertedDate = new Date();
                                        try {
                                            convertedDate = dateFormat.parse(date);
                                            System.out.println(date);
                                            formattedDate = targetFormat.format(convertedDate);
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                        Log.e("date", formattedDate);
                                        String img = json2.getString("featured_image_link");
                                        *//* String comment = json2.getString("comment_count");*//*
                                        //String category = json2.getString("categories");
                                        JSONArray cattitle = json2.getJSONArray("category_arr");
                                        JSONObject cat = cattitle.getJSONObject(0);
                                        String category = String.valueOf(Html.fromHtml(cat.getString("name")));
                                        eventmentlist.add(new EvenmentDataBean(id, title, formattedDate,*//*unlike,*//* img, category));
                                        //bindCategoryAdapternews();
                                        adapterEventment.notifyDataSetChanged();
                                        adapterEventment.setLoaded();
                                    }
                                }
                            }
                        }
*/
                        Log.e("Cat size : ", eventmentlist.size() + "");
                    }/*else {
                        progressDialog.dismiss();
                        eventmentlist.remove(eventmentlist.size() - 1);
                        adapterEventment.notifyItemRemoved(eventmentlist.size());
                        Toast.makeText(getActivity(), "No recored available", Toast.LENGTH_SHORT).show();
                    }*/
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void bindCategoryAdapter() {
        if (categorylist.size() > 0) {

            /*if (catidfromdrawer.equalsIgnoreCase("") && TextUtils.isEmpty(catidfromdrawer)) {*/
                catid = categorylist.get(0).getId();
                for (int i = 0; i <categorylist.size() ; i++) {
                    if(categorylist.get(i).getId().equals(selectedId)){
                        categorylist.get(i).setSelected(true);
                        selectedText.setText(categorylist.get(i).getName());
                        catid = categorylist.get(i).getId();
                        //bindCategoryAdapternews();

                    }else{
                        categorylist.get(i).setSelected(false);
                    }
                }
//                categorylist.get(0).setSelected(true);
//                selectedText.setText(categorylist.get(0).getName());
            } else {

                catid = catidfromdrawer;
                categorylist.get(positionFromDrawer).setSelected(true);
                selectedText.setText(Html.fromHtml(categorylist.get(positionFromDrawer).getName()));
            }
            myAdapter.notifyDataSetChanged();


            getNewsId(per_page);

       /* }*/
    }

    private void bindCategoryAdapternews() {
        if (eventmentlist.size() > 0) {
        /*    llNoDataFound.setVisibility(View.GONE);
            rvalldata.setVisibility(View.VISIBLE);*/
            adapterEventment = new AdapterEventment(getActivity(), eventmentlist, rvalldata);
          //  adapterEventment.setOnLoadMoreListener(this);
            adapterEventment.setOnNewsidSelectedListner(this);
            rvalldata.setAdapter(adapterEventment);
        }/*else {
            llNoDataFound.setVisibility(View.VISIBLE);
            rvalldata.setVisibility(View.GONE);
        }*/
    }

    @Override
    public void setOnCategorySelatedListner(int position, CategoriesBean dataBean) {

        for (int i = 0; i < categorylist.size(); i++) {
            categorylist.get(i).setSelected(false);
        }
        myAdapter.notifyDataSetChanged();
        catid = dataBean.getId();
        selectedText.setText(dataBean.getName());
        getNewsId(per_page);
        dataBean.setSelected(true);
    }

    @Override
    public void setOnNewsidSelatedListner(int position, EvenmentDataBean evenmentDataBean) {
        newsId = eventmentlist.get(position).getId();

        Intent intent = new Intent(getActivity(), NewsDetailActivity.class);
        intent.putExtra("NewsID", newsId);
        startActivity(intent);
    }


   /* @Override
    public void onLoadMore() {
        progressDialog.dismiss();
        Log.e("haint", "Load More");
        if (!adapterEventment.isLoading) {
            eventmentlist.add(null);
            adapterEventment.notifyDataSetChanged();
            per_page++;
            getNewsId(per_page);
        }
    }*/
}
