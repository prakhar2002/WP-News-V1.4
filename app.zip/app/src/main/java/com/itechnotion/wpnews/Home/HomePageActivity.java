package com.itechnotion.wpnews.Home;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.itechnotion.wpnews.AlldataFragment;
import com.itechnotion.wpnews.Contactus.ContactusFragment;
import com.itechnotion.wpnews.Evenements.AdapterEventment;
import com.itechnotion.wpnews.Evenements.EvenmentDataBean;
import com.itechnotion.wpnews.R;
import com.itechnotion.wpnews.Search.SearchActivity;
import com.itechnotion.wpnews.Setting.FAQFragment;
import com.itechnotion.wpnews.Setting.SettingFragment;
import com.itechnotion.wpnews.YoutubeActivity;
import com.itechnotion.wpnews.utils.AppConstants;
import com.itechnotion.wpnews.utils.SharedObjects;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity implements ItemClickListener<NavigationDrawerModel>, MyAdapter.OnCategorySelectedListner {
    TextView setitem;
    boolean isAdd=true;//if value is false then ads are not display
    boolean doubleBackToExitPressedOnce = false;
    private MyAdapter myAdapter;
    private ArrayList<CategoriesBean> categorylist = new ArrayList<>();
    ProgressDialog progressDialog;
    String catid;
    SharedObjects sharedObjects;
    public static TextView tvToolbarTitle;
    LinearLayout llHome, llLivetv, llCategories, llContactus, llSetting, llFaq, llSharing, llRating;
    InterstitialAd mInterstitialAd;
    public HomePageActivity() {

    }

    ImageView ivBack;
    TextView logo;
    DrawerLayout drawerLayout;
    private List<NavigationDrawerModel> mNavigationList = new ArrayList<>();
    RecyclerView rvNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        if (isAdd==true) {
            InterstitialAd();
        }else {

        }
        isNetworkConnectionAvailable();
        loadFragment(new HomeFragment(), R.id.fl_container, true);
        tvToolbarTitle = findViewById(R.id.tvToolbarTitle);
        tvToolbarTitle.setText(getString(R.string.app_name));
        drawerLayout = findViewById(R.id.drawerlayout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.setDrawerIndicatorEnabled(false);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayout);
        final DrawerLayout finalDrawer = drawerLayout;
        toggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (finalDrawer.isDrawerVisible(GravityCompat.START)) {
                    finalDrawer.closeDrawer(GravityCompat.START);
                } else {
                    finalDrawer.openDrawer(GravityCompat.START);
                }
            }
        });
        toggle.syncState();
        ivBack = findViewById(R.id.ivBackBtn);
        logo = findViewById(R.id.tvToolbarTitle);
        rvNavigation = findViewById(R.id.rv_navigation);
        llHome = findViewById(R.id.ll_home);
        llLivetv = findViewById(R.id.ll_livetv);
        llCategories = findViewById(R.id.ll_categories);
        llContactus = findViewById(R.id.ll_contact_us);
        llSetting = findViewById(R.id.ll_setting);
        llFaq = findViewById(R.id.ll_faq);
        llSharing = findViewById(R.id.ll_share);
        llRating = findViewById(R.id.ll_rate);

        llHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);
                loadFragment(new HomeFragment(), R.id.fl_container, false);
            }
        });
        llLivetv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);
                /*   replaceFragment(new LiveTvFragment(), R.id.fl_container, true);*/
                Intent i = new Intent(HomePageActivity.this, YoutubeActivity.class);
                startActivity(i);
            }
        });
        llCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);

                loadFragment(new CategoriesFragment(), R.id.fl_container, false);

            }
        });
        llContactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);
                loadFragment(new ContactusFragment(), R.id.fl_container, false);
            }
        });
        llSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);
                loadFragment(new SettingFragment(), R.id.fl_container, false);
            }
        });
        llFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvToolbarTitle.setText(getString(R.string.app_name));
                drawerLayout.closeDrawer(GravityCompat.START);
                loadFragment(new FAQFragment(), R.id.fl_container, false);
            }
        });
        llSharing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=com.example.admin.wpnews.Home");//com.itechnotion.allinone
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
        llRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showRateDialog();
            }
        });
        ivBack.setImageResource(R.drawable.menuicon);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new HomeFragment(), R.id.fl_container, false);
            }
        });
        initComponent();


    }
    public void InterstitialAd(){
        mInterstitialAd = new InterstitialAd(this);

        // set the ad unit ID
        mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
        // mInterstitialAd.setAdUnitId("ca-app-pub-4906098412516661/9907689540");

        AdRequest adRequest = new AdRequest.Builder()
                .build();

        // Load ads into Interstitial Ads
        mInterstitialAd.loadAd(adRequest);

        mInterstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
                showInterstitial();
            }
        });
    }

    private void showInterstitial() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();

        }


    }

    public void showRateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomePageActivity.this)
                .setTitle("Rate application")
                .setMessage("Please, rate the app at Playstore")
                .setPositiveButton("RATE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (getApplication() != null) {
                            String link = "market://details?id=";
                            try {
                                // play market available
                                getPackageManager()
                                        .getPackageInfo("com.itechnotion.allinone", 0);
                                // not available
                            } catch (PackageManager.NameNotFoundException e) {
                                e.printStackTrace();
                                // should use browser
                                link = "https://play.google.com/store/apps/details?id=";
                            }
                            // starts external action
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse(link + HomePageActivity.this.getPackageName())));
                        }
                    }
                })
                .setNegativeButton("CANCEL", null);
        builder.show();
    }

    public void checkNetworkConnection() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("No Internet Connection");
        builder.setMessage("Please turn on internet connection to continue");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        TextView titleView = (TextView) alertDialog.findViewById(android.R.id.message);
        titleView.setGravity(Gravity.CENTER);

    }

    public boolean isNetworkConnectionAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnected();
        if (isConnected) {
            Log.d("Network", "Connected");
            return true;
        } else {
            checkNetworkConnection();
            Log.d("Network", "Not Connected");
            //     sharedObjects.getFeaturnews("FeatureNews");
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.home, menu);
        MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) myActionMenuItem.getActionView();
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        EditText searchEditText = (EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(Color.BLACK);


        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(false);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Log.e("Submit", query);

                (menu.findItem(R.id.action_search)).collapseActionView();
                Intent intent = new Intent(HomePageActivity.this, SearchActivity.class);
                intent.putExtra(AppConstants.KEYWORD, query);
                startActivity(intent);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.e("TextChange", newText);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_search) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void ProgressDialogSetup() {
        if (HomePageActivity.this != null) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage(getResources().getString(R.string.please_wait));
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
        }
    }

    private void initComponent() {
        ProgressDialogSetup();
        rvNavigation.setLayoutManager(new LinearLayoutManager(this));
        rvNavigation.setNestedScrollingEnabled(false);
    }

    private void loadFragment(Fragment fragment, int fl_container, boolean b) {
        String backStateName = fragment.getClass().getName();
        FragmentManager fm = getSupportFragmentManager();
        boolean fragmentPopped = fm.popBackStackImmediate(backStateName, 0);
        if (!fragmentPopped) { //fragment not in back stack, create it.
            FragmentTransaction ft = fm.beginTransaction();
            ft.replace(R.id.fl_container, fragment);
            ft.addToBackStack(backStateName);
            ft.commit();
        }
    }

    @Override
    public void onItemClicked(int position, SubCategoriesModel model) {
        if (drawerLayout.isDrawerOpen(Gravity.START))
            mNavigationList.get(position).setSelected(true);
        Bundle bundle = new Bundle();
        bundle.putString("id", model.getCatID());
        bundle.putInt("position", position);
        AlldataFragment alldataFragment = new AlldataFragment();
        alldataFragment.setArguments(bundle);
        loadFragment(alldataFragment, R.id.fl_container, false);

    }

    @Override
    public void setOnCategorySelatedListner(int position, CategoriesBean dataBean) {
        for (int i = 0; i < categorylist.size(); i++) {
            categorylist.get(i).setSelected(false);
        }
        myAdapter.notifyDataSetChanged();
        catid = dataBean.getId();
        setitem.setText(dataBean.getName());
        dataBean.setSelected(true);

    }

    @Override
    public void onBackPressed() {
        progressDialog.dismiss();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawerlayout);
        tvToolbarTitle.setText(getString(R.string.app_name));
        if (getSupportFragmentManager().getBackStackEntryCount() == 1) {
            drawer.closeDrawer(GravityCompat.START);
            finish();
        } else {
            super.onBackPressed();
        }

    }

}
