package com.itechnotion.wpnews.utils;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.multidex.MultiDexApplication;
import android.support.v7.app.AlertDialog;
import android.util.Patterns;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.facebook.stetho.Stetho;
import com.google.gson.Gson;
import com.itechnotion.wpnews.R;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Sunil on 23-Oct-16.
 */
public class SharedObjects extends MultiDexApplication {

    public static Context context;
    public PreferencesEditor preferencesEditor = new PreferencesEditor();

    public static Context getContext() {
        return context;
    }

    public SharedObjects(Context context) {
        this.context = context;
        initializeStetho();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public void initializeStetho() {
        Stetho.InitializerBuilder initializerBuilder = Stetho.newInitializerBuilder(context);
        initializerBuilder.enableWebKitInspector(Stetho.defaultInspectorModulesProvider(context));
        initializerBuilder.enableDumpapp(Stetho.defaultDumperPluginsProvider(context));
        Stetho.Initializer initializer = initializerBuilder.build();
        Stetho.initialize(initializer);
    }

    public class PreferencesEditor {
        public void setBoolean(String key, boolean value) {
            SharedPreferences sharedPreference = PreferenceManager.getDefaultSharedPreferences(context);
            SharedPreferences.Editor editor = sharedPreference.edit();
            editor.putBoolean(key, value);
            editor.commit();
        }

        public Boolean getBoolean(String key) {
            try {
                SharedPreferences sharedPreference = PreferenceManager.getDefaultSharedPreferences(context);
                return sharedPreference.getBoolean(key, true);
            } catch (Exception exception) {
                return false;
            }
        }

    }
}
