package com.itechnotion.wpnews.Search;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.itechnotion.wpnews.Evenements.AdapterEventment;
import com.itechnotion.wpnews.Evenements.EvenmentDataBean;
import com.itechnotion.wpnews.Home.HomePageActivity;
import com.itechnotion.wpnews.NewsDetailActivity;

import com.itechnotion.wpnews.R;
import com.itechnotion.wpnews.retrofit.RestClient;
import com.itechnotion.wpnews.utils.AppConstants;
import com.google.gson.JsonElement;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity implements View.OnClickListener, AdapterEventment.OnNewsidSelectedListner {
    ProgressDialog progressDialog;
    NewsBySearchAdapter newsByIDAdapter;
    ArrayList<EvenmentDataBean> newslist;
    RecyclerView rvNews;
    LinearLayout llNoDataFound;
    Toolbar toolbar;
    TextView logo;
    ImageView ivBackBtn, ivOptionBtn;
    String newsId;

    String searchWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        initView();
    }
    private void initView(){
        toolbar = findViewById(R.id.toolbar);
        ivBackBtn = findViewById(R.id.ivBackBtn);
        ivBackBtn.setOnClickListener(this);
        logo = findViewById(R.id.tvToolbarTitle);
        logo.setText("Search result");
        setSupportActionBar(toolbar);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SearchActivity.this, HomePageActivity.class);
                startActivity(i);
            }
        });
        rvNews = (RecyclerView) findViewById(R.id.rvNews);
        llNoDataFound = findViewById(R.id.llNoDataFound);
        ProgressDialogSetup();
        searchWord = getIntent().getStringExtra(AppConstants.KEYWORD);
        newslist = new ArrayList<>();
        newsByIDAdapter = new NewsBySearchAdapter(this, newslist);
        rvNews.setLayoutManager(new LinearLayoutManager(this));
        rvNews.setAdapter(newsByIDAdapter);
        getNewsByCatID();
    }
    private void ProgressDialogSetup() {
        progressDialog = new ProgressDialog(SearchActivity.this);
        progressDialog.setMessage(getResources().getString(R.string.please_wait));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);
    }

    private void getNewsByCatID() {
        progressDialog.show();
        Call<JsonElement> call1 = RestClient.post().search(searchWord);
        call1.enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                progressDialog.dismiss();
                Log.e("Search News", response.body().toString());
                try {
                    if (response.isSuccessful()) {
                        JSONArray jsonArr = new JSONArray(response.body().toString());
                        if (jsonArr.length() > 0) {
                            for (int i = 0; i < jsonArr.length(); i++) {
                                JSONObject json2 = jsonArr.getJSONObject(i);
                                String id = json2.getString("id");
                                JSONObject objtitle = json2.getJSONObject("title");
                                String title = objtitle.getString("rendered");
                                String dateString = json2.getString("date");
                                System.out.println(dateString);
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                DateFormat targetFormat = new SimpleDateFormat("MMMM dd yyyy");
                                String formattedDate = null;
                                Date convertedDate = new Date();
                                try {
                                    convertedDate = dateFormat.parse(dateString);
                                    System.out.println(dateString);
                                    formattedDate = targetFormat.format(convertedDate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                Log.e("date", formattedDate);
                                String img = json2.getString("featured_image_link");
                                JSONArray cattitle = json2.getJSONArray("category_arr");
                                JSONObject cat = cattitle.getJSONObject(0);
                                String category = cat.getString("name");
                                newslist.add(new EvenmentDataBean(id, title, formattedDate,/*unlike,*/img, category));
                            }
                            newsByIDAdapter.notifyDataSetChanged();
                        }
                        bindCategoryAdapternews();
                        Log.e("Cat size : ", newslist.size() + "");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SearchActivity.this, getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void bindCategoryAdapternews() {

        if (newslist.size() > 0) {
            llNoDataFound.setVisibility(View.GONE);
            rvNews.setVisibility(View.VISIBLE);
            newsByIDAdapter = new NewsBySearchAdapter(SearchActivity.this, newslist);
            newsByIDAdapter.setOnNewsidSelectedListner(this);
            rvNews.setAdapter(newsByIDAdapter);
        } else {
            llNoDataFound.setVisibility(View.VISIBLE);
            rvNews.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ivBackBtn:
                onBackPressed();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void setOnNewsidSelatedListner(int position, EvenmentDataBean evenmentDataBean) {
        newsId = newslist.get(position).getId();

        Intent intent = new Intent(SearchActivity.this, NewsDetailActivity.class);
        intent.putExtra("NewsID", newsId);
        startActivity(intent);
    }

}
