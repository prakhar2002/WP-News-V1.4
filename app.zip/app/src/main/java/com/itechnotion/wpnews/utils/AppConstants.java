package com.itechnotion.wpnews.utils;
public class AppConstants {
    public static final String KEYWORD = "world";
    public static final String YOUTUBE = "AIzaSyATcpF10RHJ2ChC4pQnNBhNpRPxkBxyUzo";
    public static final String NEWS_ID = "id";
    public static String email = "Email";
    public static String isChecked="isChecked";
}
