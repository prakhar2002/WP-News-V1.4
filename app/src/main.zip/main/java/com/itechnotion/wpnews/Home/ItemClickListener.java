package com.itechnotion.wpnews.Home;

public interface ItemClickListener<T> {
    void onItemClicked(int position, SubCategoriesModel model);
}